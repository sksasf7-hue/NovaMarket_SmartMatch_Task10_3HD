/*
  SIT774 Task 10.3HD - NovaMarket SmartMatch
  Client-side behaviour for the innovative website feature prototype.
*/

const state = {
  products: [],
  categories: [],
  selectedCompare: new Map(),
  sessionToken: localStorage.getItem('novamarket-session') || crypto.randomUUID(),
};
localStorage.setItem('novamarket-session', state.sessionToken);

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));

function money(value) {
  return new Intl.NumberFormat('en-AU', { style: 'currency', currency: 'AUD' }).format(value);
}

function escapeHTML(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await response.json();
  if (!response.ok || data.ok === false) {
    const message = data.errors ? data.errors.join(' ') : 'Request failed.';
    throw new Error(message);
  }
  return data;
}

function updateStats(stats) {
  if (!stats) return;
  const statsGrid = $('#statsGrid');
  if (!statsGrid) return;
  statsGrid.innerHTML = `
    <article class="metric-card"><strong>${stats.product_count}</strong><span>Products</span></article>
    <article class="metric-card"><strong>${stats.average_rating}</strong><span>Avg rating</span></article>
    <article class="metric-card"><strong>${stats.recommendation_count}</strong><span>Matches run</span></article>
    <article class="metric-card"><strong>${stats.wishlist_count}</strong><span>Wishlist clicks</span></article>
  `;
}

function populateCategorySelects() {
  const options = state.categories.map((category) => `<option value="${escapeHTML(category)}">${escapeHTML(category)}</option>`).join('');
  $('#category').insertAdjacentHTML('beforeend', options);
  $('#catalogFilter').insertAdjacentHTML('beforeend', options);
  $('#productCategory').innerHTML = options;
}

function stockLabel(product) {
  if (product.stock_qty <= 0) return '<span class="pill stock-out">Out of stock</span>';
  if (product.stock_qty < 10) return `<span class="pill stock-low">${product.stock_qty} left</span>`;
  return `<span class="pill">${product.stock_qty} in stock</span>`;
}

function productMeta(product) {
  return `
    <div class="product-meta">
      <span class="pill">${escapeHTML(product.category)}</span>
      <span class="pill">★ ${product.rating.toFixed(1)}</span>
      <span class="pill">Eco ${product.eco_score}</span>
      <span class="pill">Access ${product.accessibility_score}</span>
      ${stockLabel(product)}
    </div>
  `;
}

function resultCard(product, rank) {
  const reasons = product.match_reasons.map((reason) => `<span class="reason-chip">${escapeHTML(reason)}</span>`).join('');
  const bars = product.score_breakdown.map((item) => {
    const percent = Math.round((item.value / item.max) * 100);
    return `
      <div class="breakdown-row">
        <span>${escapeHTML(item.label)}</span>
        <span class="progress-track" aria-hidden="true"><span class="progress-fill" style="--width:${percent}%"></span></span>
        <strong>${percent}%</strong>
      </div>
    `;
  }).join('');

  return `
    <article class="result-card" aria-label="Recommendation ${rank}: ${escapeHTML(product.product_name)}">
      <div class="card-top">
        <div class="product-identity">
          <span class="product-icon" aria-hidden="true">${product.icon}</span>
          <div>
            <p class="eyebrow">#${rank} ${escapeHTML(product.badge)}</p>
            <h3>${escapeHTML(product.product_name)}</h3>
            ${productMeta(product)}
          </div>
        </div>
        <div class="score-ring" style="--score:${product.match_score}" aria-label="Match score ${product.match_score} out of 100">
          <strong>${product.match_score}</strong>
        </div>
      </div>
      <div class="result-body">
        <p>${escapeHTML(product.description)}</p>
        <div class="reason-list" aria-label="Recommendation reasons">${reasons}</div>
        <div class="breakdown-list" aria-label="Score breakdown">${bars}</div>
      </div>
      <div class="card-actions">
        <button class="text-btn" type="button" data-wishlist="${product.product_id}">Save to wishlist</button>
        <button class="text-btn" type="button" data-compare="${product.product_id}">Compare</button>
      </div>
    </article>
  `;
}

function productCard(product) {
  const features = product.features.map((feature) => `<span class="reason-chip">${escapeHTML(feature)}</span>`).join('');
  const selected = state.selectedCompare.has(product.product_id) ? 'Remove compare' : 'Compare';
  return `
    <article class="product-card">
      <div class="card-top">
        <div class="product-identity">
          <span class="product-icon" aria-hidden="true">${product.icon}</span>
          <div>
            <p class="eyebrow">${escapeHTML(product.badge)}</p>
            <h3>${escapeHTML(product.product_name)}</h3>
          </div>
        </div>
      </div>
      ${productMeta(product)}
      <div class="product-body">
        <p>${escapeHTML(product.description)}</p>
        <div class="feature-list">${features}</div>
        <div class="price-line">
          <strong class="price">${money(product.unit_price)}</strong>
          <span class="pill">Performance ${product.performance_score}</span>
        </div>
      </div>
      <div class="card-actions">
        <button class="text-btn" type="button" data-wishlist="${product.product_id}">Save to wishlist</button>
        <button class="text-btn" type="button" data-compare="${product.product_id}">${selected}</button>
      </div>
    </article>
  `;
}

function renderCatalog() {
  const term = $('#searchBox').value.trim().toLowerCase();
  const filter = $('#catalogFilter').value;
  const products = state.products.filter((product) => {
    const haystack = [product.product_name, product.category, product.description, product.features.join(' ')].join(' ').toLowerCase();
    const matchesSearch = !term || haystack.includes(term);
    const matchesCategory = filter === 'All' || product.category === filter;
    return matchesSearch && matchesCategory;
  });
  $('#productGrid').innerHTML = products.length
    ? products.map(productCard).join('')
    : '<div class="empty-state"><span aria-hidden="true">🔎</span><p>No matching products found.</p></div>';
}

// Awesome feature: submits preference data to the recommendation API and renders explainable results.
async function handleSmartMatch(event) {
  event.preventDefault();
  const panel = $('.results-panel');
  const list = $('#resultsList');
  const latency = $('#latencyBadge');
  const form = new FormData(event.currentTarget);
  const payload = {
    session_token: state.sessionToken,
    category: form.get('category'),
    budget: form.get('budget'),
    priority: form.get('priority'),
    usage: form.get('usage'),
    include_unavailable: $('#includeUnavailable').checked,
  };

  panel.setAttribute('aria-busy', 'true');
  list.classList.add('loading');
  list.innerHTML = '';
  latency.textContent = 'Matching...';

  try {
    const data = await api('/api/recommend', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    updateStats(data.stats);
    latency.textContent = `${data.elapsed_ms} ms`;
    list.classList.remove('loading');
    list.innerHTML = data.results.length
      ? data.results.map((product, index) => resultCard(product, index + 1)).join('')
      : '<div class="empty-state"><span aria-hidden="true">🧭</span><p>No products matched. Try increasing the budget or include waitlist products.</p></div>';
  } catch (error) {
    list.classList.remove('loading');
    list.innerHTML = `<div class="empty-state"><span aria-hidden="true">⚠️</span><p>${escapeHTML(error.message)}</p></div>`;
    latency.textContent = 'Error';
  } finally {
    panel.setAttribute('aria-busy', 'false');
  }
}

async function handleWishlist(productId, button) {
  button.disabled = true;
  const oldText = button.textContent;
  button.textContent = 'Saving...';
  try {
    const data = await api('/api/wishlist', {
      method: 'POST',
      body: JSON.stringify({ session_token: state.sessionToken, product_id: productId }),
    });
    updateStats(data.stats);
    button.textContent = 'Saved ✓';
  } catch (error) {
    button.textContent = 'Try again';
    button.title = error.message;
  } finally {
    setTimeout(() => {
      button.disabled = false;
      if (button.textContent !== 'Try again') button.textContent = oldText;
    }, 1400);
  }
}

function toggleCompare(productId) {
  const product = state.products.find((item) => item.product_id === Number(productId));
  if (!product) return;
  if (state.selectedCompare.has(product.product_id)) {
    state.selectedCompare.delete(product.product_id);
  } else {
    if (state.selectedCompare.size >= 3) {
      alert('You can compare up to three products at a time.');
      return;
    }
    state.selectedCompare.set(product.product_id, product);
  }
  renderCatalog();
  renderCompare();
}

function renderCompare() {
  const selected = Array.from(state.selectedCompare.values());
  $('#compareCount').textContent = selected.length;

  if (!selected.length) {
    $('#compareContent').innerHTML = '<p class="empty-state"><span aria-hidden="true">📊</span>No products selected yet. Use Compare on any product card.</p>';
    return;
  }

  const rows = [
    ['Price', (p) => money(p.unit_price)],
    ['Rating', (p) => `★ ${p.rating.toFixed(1)}`],
    ['Eco score', (p) => p.eco_score],
    ['Accessibility', (p) => p.accessibility_score],
    ['Performance', (p) => p.performance_score],
    ['Stock', (p) => p.stock_qty],
  ];

  const tableRows = rows.map(([label, getter]) => `
    <tr>
      <th scope="row">${label}</th>
      ${selected.map((product) => `<td>${getter(product)}</td>`).join('')}
    </tr>
  `).join('');

  $('#compareContent').innerHTML = `
    <table class="compare-table">
      <thead>
        <tr><th scope="col">Metric</th>${selected.map((p) => `<th scope="col">${escapeHTML(p.product_name)}</th>`).join('')}</tr>
      </thead>
      <tbody>${tableRows}</tbody>
    </table>
    ${selected.map((product) => `
      <div class="compare-item">
        <strong>${escapeHTML(product.icon)} ${escapeHTML(product.product_name)}</strong>
        <p>${escapeHTML(product.description)}</p>
        <button class="text-btn" type="button" data-compare="${product.product_id}">Remove</button>
      </div>
    `).join('')}
  `;
}

async function handleProductAdd(event) {
  event.preventDefault();
  const status = $('#productStatus');
  status.className = 'status-box';
  status.textContent = 'Saving product...';
  const formData = new FormData(event.currentTarget);
  const payload = Object.fromEntries(formData.entries());

  try {
    const data = await api('/api/add-product', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    status.className = 'status-box success';
    status.textContent = data.message;
    state.products = data.products;
    updateStats(data.stats);
    renderCatalog();
  } catch (error) {
    status.className = 'status-box error';
    status.textContent = error.message;
  }
}

async function handleContact(event) {
  event.preventDefault();
  const status = $('#contactStatus');
  status.className = 'status-box';
  status.textContent = 'Saving message...';
  const formData = new FormData(event.currentTarget);
  const payload = Object.fromEntries(formData.entries());

  try {
    const data = await api('/api/contact', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    status.className = 'status-box success';
    status.textContent = data.message;
    updateStats(data.stats);
  } catch (error) {
    status.className = 'status-box error';
    status.textContent = error.message;
  }
}

function setupTheme() {
  const saved = localStorage.getItem('novamarket-theme') || 'dark';
  document.documentElement.dataset.theme = saved;
  $('#themeToggle').addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    localStorage.setItem('novamarket-theme', next);
  });
}

function setupMenu() {
  const toggle = $('#menuToggle');
  const links = $('#navLinks');
  toggle.addEventListener('click', () => {
    const open = links.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
  });
  links.addEventListener('click', (event) => {
    if (event.target.matches('a')) {
      links.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
    }
  });
}

function setupRevealAnimation() {
  const items = $$('.reveal');
  if (!('IntersectionObserver' in window)) {
    items.forEach((item) => item.classList.add('visible'));
    return;
  }
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  items.forEach((item) => observer.observe(item));
}

function setupGlobalActions() {
  document.addEventListener('click', (event) => {
    const wishlistButton = event.target.closest('[data-wishlist]');
    if (wishlistButton) {
      handleWishlist(wishlistButton.dataset.wishlist, wishlistButton);
      return;
    }
    const compareButton = event.target.closest('[data-compare]');
    if (compareButton) {
      toggleCompare(compareButton.dataset.compare);
    }
  });

  $('#openCompare').addEventListener('click', () => {
    $('#compareDrawer').classList.add('open');
    $('#compareDrawer').setAttribute('aria-hidden', 'false');
    $('#closeCompare').focus();
  });
  $('#closeCompare').addEventListener('click', () => {
    $('#compareDrawer').classList.remove('open');
    $('#compareDrawer').setAttribute('aria-hidden', 'true');
    $('#openCompare').focus();
  });

  $('#searchBox').addEventListener('input', renderCatalog);
  $('#catalogFilter').addEventListener('change', renderCatalog);
  $('#smartForm').addEventListener('submit', handleSmartMatch);
  $('#productForm').addEventListener('submit', handleProductAdd);
  $('#contactForm').addEventListener('submit', handleContact);
}

async function boot() {
  setupTheme();
  setupMenu();
  setupRevealAnimation();
  setupGlobalActions();

  try {
    const data = await api('/api/products');
    state.products = data.products;
    state.categories = data.categories;
    populateCategorySelects();
    updateStats(data.stats);
    renderCatalog();
    renderCompare();
  } catch (error) {
    $('#productGrid').innerHTML = `<div class="empty-state"><span aria-hidden="true">⚠️</span><p>${escapeHTML(error.message)}</p></div>`;
  }
}

document.addEventListener('DOMContentLoaded', boot);
